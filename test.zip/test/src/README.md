# shopFINAL

#Shop Final

#4/24/2023

#https://github.com/stg5244?tab=repositories

#Original Website: https://www.free-css.com/free-css-templates/page282/pro

#List of Changes from original:
1. Changed "our protein" to "our games".
2. Changed all variables containing "protein" to contain "games".
3. Changed "Pro Body Builder Protein" to be "VaporForge Games".
4. Changed the page title "pro" to "VaporForge".
5. Changed the images of the protein to be the cover art of 7 games.
6. Added 3 more slots for games.
7. Changed the about us section.
8. Changed the information section at the bottom of page.
9. Removed pictures of the stock product.
10. Cleaned up lots of variables. ex. "tesimo" to "testimonial" .
11. Changed all testimonial texts, names, and images.
12. Added a call to action above the testimonials. 
13. Changed the Helpful Links section
14. Changed the stock phone number and email towards the bottom of the page.
15. Changed the color of the top banner to be orange
16. Changed the testimonials color to be orange
17. Changed the bottom section to be a grey
18. Added a border above and below the about us section
19. Changed some of the text color in the bottom section to be a dark grey.
20. Added a map to the bottom of the page for the location
21. Made the bottom buttons link to the default page for facebook, twitter, linkedin, and instagram
22. Added functionality to the helpful links buttons a the bottom of the page. Our games, about us, testimonial.
